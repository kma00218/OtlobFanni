مجلد أيقونات تطبيق اطلب فني

انسخ مجلد public داخل مشروع Replit.
المسار النهائي يجب أن يكون:
public/icons/services/

استخدم الملفات بهذا الشكل:
<img src="/icons/services/electricity.svg" />

تم تجهيز 20 أيقونة أساسية + أسماء بديلة لبعض الملفات.
